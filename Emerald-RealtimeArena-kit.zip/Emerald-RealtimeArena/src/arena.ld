INCLUDE gamesyms.ld
SECTIONS {
  . = 0x09000000;
  .text : { KEEP(*(.header)) *(.text*) }
  .rodata : { *(.rodata*) *(.rodata.*) }
  .data : { *(.data*) }
  /DISCARD/ : { *(.ARM.exidx*) *(.comment) *(.ARM.attributes) *(.note*) *(.bss*) *(COMMON) }
}

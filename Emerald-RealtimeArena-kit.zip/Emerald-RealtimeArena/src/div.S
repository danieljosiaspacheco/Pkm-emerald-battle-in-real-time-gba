    .syntax unified
    .thumb
    .text
    .global __aeabi_idiv
    .global __aeabi_idivmod
    .thumb_func
__aeabi_idiv:
    swi 6
    bx lr
    .thumb_set __aeabi_idivmod, __aeabi_idiv
    .global __aeabi_uidiv
    .global __aeabi_uidivmod
    .thumb_func
__aeabi_uidiv:
    @ unsigned: use signed BIOS Div when both operands fit in 31 bits, otherwise bit loop
    push {r4, r5, lr}
    movs r4, r0
    movs r5, r1
    lsrs r2, r0, #31
    lsrs r3, r1, #31
    orrs r2, r3
    bne 1f
    swi 6
    pop {r4, r5, pc}
1:  @ slow path: shift-subtract
    movs r2, #0         @ quotient
    movs r3, #0         @ remainder
    movs r0, #32
2:  lsls r3, r3, #1
    lsrs r1, r4, #31
    orrs r3, r1
    lsls r4, r4, #1
    lsls r2, r2, #1
    cmp r3, r5
    blo 3f
    subs r3, r3, r5
    adds r2, r2, #1
3:  subs r0, r0, #1
    bne 2b
    movs r0, r2
    movs r1, r3
    pop {r4, r5, pc}
    .thumb_set __aeabi_uidivmod, __aeabi_uidiv

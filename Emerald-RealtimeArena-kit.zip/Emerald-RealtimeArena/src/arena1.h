// arena1.h - shared definitions for the real-time arena engine
#ifndef ARENA1_H
#define ARENA1_H
#include "gba.h"
#include "game.h"
#include "gfx.h"
#include "gfx_floors.h"

#define PACK ((const u8 *)0x09020000)

enum { ANIM_WALK, ANIM_ATTACK, ANIM_SHOOT, ANIM_HURT, ANIM_SLEEP };
enum { ST_FADEIN, ST_INTRO, ST_FIGHT, ST_END, ST_FADEOUT, ST_UI, ST_SEND };
enum { UI_MENU = 1, UI_SWITCH, UI_LEARN, UI_NICK, UI_BAG, UI_ITEMTGT, UI_ITEMMV, UI_EVO };
enum { EV_MSG, EV_LEARN, EV_NICK, EV_MONEY };
enum { PH_FREE, PH_ATTACK, PH_HURT, PH_FAINT, PH_CAPTURED };
enum { K_SELF, K_MELEE, K_SPREAD, K_BOLT };
enum { S_NONE, S_SLEEP, S_POISON, S_BURN, S_FREEZE, S_PARA, S_TOXIC };
enum { CAP_NONE, CAP_FLY, CAP_ABSORB, CAP_SHAKE, CAP_SUCCESS, CAP_BREAK };

#define NTB 1
#define FIELD_W_MIN 24
#define FIELD_W_MAX 216
#define FIELD_H_MIN 52
#define FIELD_H_MAX 132

typedef struct Actor {
    s32 x, y;              // feet position, 24.8 fixed
    s32 kx, ky;            // knockback velocity 8.8
    u8 dir, isPlayer, phase, anim;
    u8 aIdx, aTick, aLoop, animDone;
    u8 hitFired, hitIdx, moving, alive;
    u8 curFrame, upPending, retired, palBank;
    u8 shape, size, ox, oy;
    u8 w, h, tiles, nframes;
    u16 species, nat;
    u16 level;
    s16 hp, maxHp;
    u16 stat[5];           // atk def spe spa spd
    s8 stage[7];           // atk def spe spa spd acc eva
    u8 type1, type2;
    u8 status, partyIdx;
    u16 moves[4];
    u8 pp[4];
    u16 cd[4];
    u16 stun, flinchLock, statusTimer, statusTick, confTimer, confDirTimer;
    u16 flash, invuln, trapTimer, reflect, lscreen, recharge;
    u8 focus, curSlot;
    s8 confDir;
    u8 fainted;            // blink counter
    u8 toy;                // Substitute: the Pokemon looks like a toy Clefairy (toyRec = its own look) while a->reflect runs
    const u8 *toyRec;
    u8 xform;              // 1 after Transform: moves/PP are copies and must not be written back
    // AI
    u16 aiTimer, aiReact;
    s8 aiMove, aiStrafe;
    u16 aiStrafeT;
    const u8 *rec;
    struct Pokemon *mon;
    u8 name[12];           // ascii
    u16 objBase;
    u8 cols, rows, np, uh;  // big sprites: cols x rows pieces of 64x64 (np really drawn), uh = content height
    u16 pb[4];              // VRAM tile base of each piece
    u8 relT, relDelay, relBall, relPad;   // relPad: 1 = the current attack is Struggle (move out of PP)
      // Poke Ball release at the start: relDelay frames of waiting, then relT frames left (0 = none); relBall = ball sprite index
    u16 roll, rollMv; u8 rollN, rollCd; s16 rvx, rvy;      // Rollout: frames left, hits so far, cooldown after a hit, velocity 8.8
    u8 bx0, bx1, by0, by1;      // bounding box of the opaque pixels of the current frame (frame coordinates)
    u8 lx0, lx1, ly0, ly1;      // where the feet may go so that the picture reaches the walls but not beyond
} Actor;

typedef struct Proj {
    s32 x, y, vx, vy;
    u16 life, move;
    u8 active, kind, owner, ptype;
    u8 pal;
} Proj;

typedef struct Popup {
    s16 x, y;
    u16 timer;
    u8 len, pal;
    char text[8];
} Popup;

typedef struct Fx {
    s16 x, y;
    u8 timer, kind, active, pad;
} Fx;

typedef struct DObj {
    u16 a0, a1, a2;
    s16 key;
} DObj;

typedef struct Ev { u8 type, a; u16 b; char text[32]; } Ev;

typedef struct Arena {
    u8 state;
    u8 pad0, partyUsedMask, ballSel;
    u16 stateTimer, msgTimer;
    u32 frame;
    Actor act[4];          // 0 player 1, 1 enemy 1, 2 player 2, 3 enemy 2 (even = player side)
    Proj proj[10];
    Popup pop[8];
    Fx fx[8];
    // capture
    u8 capState, capShakes, capSuccessAt, capBall;
    u16 capTimer;
    s16 capX, capY;
    u8 capDone;
    u8 outcome;
    u8 runHold;
    u16 ballCd;
    u16 bgDirty, obdirty;
    u8 fadeLevel; u8 typeBankType[10]; u8 typeBankAge[10];
    u16 dispcnt;
    u16 hudCache, hudCache2;
    char msg[32];
    Ev evq[16];
    u8 evN, evI; u16 evT;
    u16 bgmap[32 * 32];
    u16 objPal[256];
    u8 stage[4][2048];
    u8 *bstage[4];         // 8 KB staging buffers for multi-piece sprites (heap, allocated on demand)
    u16 blkUsed;           // bit j: OBJ tile block 448 + 64 j is taken by a big sprite piece
    DObj dl[112];
    u8 ndl;
    u8 oldPartyCount;
    u8 enemyWasCaught;
    u8 levelUpMsg;
    u16 lastHeld;
    u16 cryPending;
    u8 ui, uiSel, uiSel2, uiForced, uiPrev;
    u8 isTrainer, enemyIdx, enemyCnt, nickWanted;
    u16 trainerId;
    u32 prize;
    u32 expGain[6];
    u32 expPool;                  // Exp earned in the fight, paid when it ends
    u8 lvlMask, lnMask, lnActive, lnFirst, lnLv, lnTo, lnIdx, endPhase;
    u16 lnMove;
    u8 oldLv[6], newLv[6];
    char tname[32];
    const u8 *fxSrc[4];
    u8 fxN[4], fxShape[4], fxSize[4], fxPend, fxOwner;
    u16 fxMove[2];
    u8 pm, dbl, page, uiSlot, endSlot, enemyNext, defeated, nmenu;
    u8 menu[8];
    u16 bagIds[64]; u8 nbag, bagTop, bagSel, itemMv, bagTab; u16 bagItem;
    u8 safari, sfLeave, sfDirT, sfDir; u16 sfBait, sfAngry, sfTimer;
    u8 terrain;
    u8 lkN;                // link: frames exchanged so far (tag of the next word)
    u8 court; u8 seN; u16 seLog[6];              // arena floor = the sand court (gyms, Elite Four, Frontier, Trainer Hill, link battles)
    u8 weather;            // 0 none, 1 sandstorm, 2 hail (until the end of the battle)
    u8 partMask;
    u8 scripted;                  // Birch rescue / Wally tutorial: no catching, no running, no EXP
    u8 two, partner, nxB, endB; u16 trainerIdB; char tnameB[32];   // two opponents / AI partner
    u8 rollMul;                   // Rollout damage multiplier (no writable globals: the code runs from ROM)
    u8 mirrorN[4];         // Reflect / Light Screen / Barrier / Mirror Move: uses so far in this battle (each Pokemon slot, at most 4)
    u8 frontier;                  // Battle Frontier battle: no EXP, no money           // party members that took part in the battle (they share the Exp unless the EXP FOR ALL option is on)
    u8 ballTile;           // index of the ball sprite used by the thrown / capturing ball
    u8 evoSt, evoIdx, evoAns; u16 evoSp, evoT; char evoNm[12];
    u8 contest, cRound, cTurn, cPhase, cHit, cMoved, cSlot, cJ[3];          // Contest Hall: whose turn, phase, hits on the bag, the judges' last marks
    u16 cTimer; u16 cLast[4]; s16 cTot[4]; u8 cOk[4], cLastSum; char cName[4][12];
    struct Pokemon cmon[4] __attribute__((aligned(4)));
    u8 link, lkMaster, lkHash, lkBad; u16 lkHeld[2]; u8 lkPage[2]; u8 lkLeft[2]; u16 lkCd[2]; u8 giveUp; void *lk;     // real-time link battle
} Arena;

extern int gArenaDebug;
#endif

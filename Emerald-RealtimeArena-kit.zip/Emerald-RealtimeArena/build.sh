#!/bin/bash
# build.sh [debug] -> build/arena.bin (+ build/arena.sym)
set -e
cd "$(dirname "$0")"
DBG="$EXTRA"; OUT=build; LD=src/arena.ld
if [ -n "$EMERALD" ]; then [ -z "$EXTRA" ] && DBG="-O1"; DBG="$DBG -DEMERALD"; OUT=build_em; LD=src/arena_em.ld; fi
mkdir -p $OUT
[ "$1" = "debug" ] && DBG="$DBG -DARENA_DEBUG" && OUT="${OUT}_debug" && mkdir -p $OUT
CF="--target=thumbv4t-none-eabi -mthumb -mcpu=arm7tdmi -Os -ffreestanding -fno-builtin -mlong-calls -fno-unwind-tables -fno-asynchronous-unwind-tables -fno-stack-protector -fno-pic -Wall -Wno-unused-function -Wno-unused-variable -Isrc $DBG"
clang $CF -c src/arena.c -o $OUT/arena.o
clang $CF -c src/rt.c -o $OUT/rt.o
clang $CF -c src/div.S -o $OUT/div.o
ld.lld -T $LD -Lsrc --no-rosegment -o $OUT/arena.elf $OUT/arena.o $OUT/rt.o $OUT/div.o
llvm-objcopy -O binary $OUT/arena.elf $OUT/arena.bin
if [ "$(llvm-size -A $OUT/arena.elf | awk '$1==".data"{print $2}')" != "0" ] && [ -n "$(llvm-size -A $OUT/arena.elf | awk '$1==".data"{print $2}')" ]; then echo "ERROR: writable globals (.data) - the code runs from ROM"; exit 1; fi
llvm-nm $OUT/arena.elf | grep -E " T (ArenaEntry|ArenaDebugEntry|DebugWarp|DebugWeather|DebugSafari|DebugHm|DebugFrontier|DebugStartWild|DebugContest|DebugCandy|LinkTest|LinkScreenInit|EvoAskMain|LinkKeyGuard)$" > $OUT/arena.sym
ls -la $OUT/arena.bin; cat $OUT/arena.sym

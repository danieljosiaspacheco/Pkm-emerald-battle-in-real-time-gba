# Pokémon Emerald - Real-time Arena 
Aplique `Emerald_Arena.bps` (ou `Emerald_Arena_alt.bps`) na ROM Pokémon Emerald (USA/Europe) v1.0, md5 605b89b67018abcea91e693a4dd25be3.

Incluído: batalhas selvagens e de treinador (simples e duplas) em tempo real com sprites do PMD, todos os golpes com os efeitos novos,
PP 5/10 -> 15, EXP/evolução na arena, captura, Safari, menu de truques no L (EASY CAPTURE, ALL POKEMON, EASY MODE, EXP FOR ALL, LINK BATTLE).
Fase 3: Battle Frontier em tempo real (Tower individual/dupla, Dome, Palace, Arena, Factory, Pike individual, Pyramid): sem EXP e sem dinheiro, EASY MODE deixa os adversários com 1/4 do HP, o resultado vai para os scripts do Frontier normalmente (a arena grava o resultado em VAR_RESULT como o jogo original faz; antes, vitórias em Factory, Palace, Pike, Dome e Arena eram lidas como derrota).

Líderes da Battle Frontier: aparecem sempre no 7º combate (Tower, Palace, Arena, Factory), na final do Dome e no último andar da Pyramid; no Pike a Rainha espera na sala 7. Só no modo individual (como no jogo). Símbolo de prata/ouro conforme os símbolos que você já tem; com os dois símbolos é a revanche. Dependendo de onde o contador de salas do Pike é incrementado, a Rainha pode aparecer uma sala antes ou depois — não testado no jogo.
Fase 5: lutas contra DOIS treinadores ao mesmo tempo (cada um com seus Pokémon e nome), a luta em dupla com o Steven como parceiro e os multi do Frontier com parceiro de IA agora são em tempo real em dupla. O parceiro é controlado pela IA e não ganha EXP.
Continuam como no jogo original: batalhas por cabo (link/multi) e as de secret base/e-reader.
Fase 4: a primeira batalha (Birch x Poochyena) e o tutorial do Wally (Ralts) agora são em tempo real: sem captura e sem fuga; o Pokémon ganha EXP no Birch (no Wally não).
HMs sem precisar de Pokémon que saiba o golpe (as insígnias continuam necessárias): Cut (árvore), Rock Smash, Strength, Surf, Waterfall, Dive. Fly: aperte R fora de prédios com a insígnia Feather. Flash: ao entrar numa caverna escura com a insígnia Knuckle aparece a pergunta 'Use FLASH?'. Câmara do Registeel: aperte R no ponto do quebra-cabeça (Knuckle).
Fase 2: o primeiro Pokémon da equipe segue o jogador e os Pokémon selvagens aparecem andando no mato, cavernas e água; encostar neles começa a luta. Repel funciona (não aparecem os de nível menor que o seu).
Rare Candy e subidas de nível no menu perguntam "DO YOU WANT TO EVOLVE?" (NO = nunca evolui, como no FireRed).
Para compilar: EMERALD=1 ./build.sh  e  python3 tools/make_rom_em.py EMERALD.gba FIRERED.gba --sprites sprites.bin out.gba

Atualização: Absorb usa o mesmo sprite do Giga Drain (bolinhas verdes). Os Pokémon da reserva ganham EXP (metade; tudo com EXP FOR ALL), podem subir de nível, aprender golpes e mostram a pergunta "quer evoluir?"; a evolução agora é gravada no time (antes a mensagem aparecia mas a forma não mudava).

Link / multiplayer local: batalha em tempo real por cabo link entre dois GBAs. Abra pelo menu L (LINK BATTLE) ou pelo balcão do Cable Club (Pokémon Center 2F, opção Colosseum). Funciona também entre Emerald Arena e FireRed Arena (cada um com o seu patch): escolha nível/modo (simples/duplo) com o D-pad e confirme com A nos dois. Trocas e Record Corner continuam como no jogo original.

Atualização: Vine Whip agora são dois cipós (fileiras de bolinhas verdes) que crescem até o inimigo; Pursuit é uma ameba roxa de pontas arredondadas.

## Atualização: socos elementais e Sludge Bomb
- Fire/Ice/Thunder Punch: punho dentro de chama/gelo/raio. Sludge Bomb: fileira comprida horizontal, como o Flamethrower.

## Atualização: Tyrogue
- Tyrogue evolui no nível 15 segurando uma bola: Poké Ball -> Hitmontop, Great Ball -> Hitmonlee, Ultra Ball -> Hitmonchan. A bola é consumida. A evolução original por Attack/Defense foi removida.

## Atualização: Stomp, Rolling Kick, Double Kick, Rollout e Hydro Pump
- Stomp: garra de urso preta batendo no alvo. Double Kick: duas pegadas pretas de sapato. Rolling Kick: círculo de pegadas pretas.
- Rollout: o Pokémon vira uma bola da sua cor e rola pela arena por 5 segundos, perseguindo o inimigo e quicando nas paredes; cada batida seguida causa mais dano (até 5x). Você não controla durante a rolagem.
- Hydro Pump: jato de água grosso e contínuo, sem formato de bolinhas.

## Atualização: Triple Kick, Dragon Breath, Dragon Claw
- Triple Kick: três pegadas pretas de sapato. Dragon Breath: coluna longa e amarela como o Flamethrower. Dragon Claw: quatro garras amarelas, duas de cada lado.

## Atualização: ingressos de evento e tutorial do Wally
- Eon Ticket, Aurora Ticket, Mystic Ticket e Old Sea Map já vêm na mochila, com os navios do porto de Lilycove liberados (Southern Island, Birth Island, Navel Rock e Faraway Island). São entregues sozinhos na primeira vez que você controla o personagem no jogo.
- Tutorial de captura do Wally: roda sozinho. Seu Pokémon enfraquece a Ralts, o Wally joga a bola e captura (sempre funciona). Ninguém desmaia, e a Ralts fica com o Wally: nada vai para o seu time nem para a Pokédex.

## Atualização: Gloom
- Gloom evolui para Bellossom no nível 22 segurando uma Poké Ball (a bola é consumida). Vileplume (Leaf Stone) e Bellossom (Sun Stone) continuam como antes.

## Atualização: bordas da arena
- Os Pokémon grandes (Onix, Snorlax, Rayquaza, Aggron...) agora chegam até as paredes em todos os lados: o limite usa o desenho de verdade, e não a moldura vazia do sprite.

## Atualização: Concurso Pokémon (Contest Hall) na arena
- Os apelos do concurso viram uma apresentação na arena: todos os golpes são mirados num saco de pancada vermelho.
- 5 rodadas; em cada uma os 4 participantes se apresentam, um golpe cada. Os 3 Pokémon rivais usam o golpe sozinhos; no seu turno você anda e aperta o botão do golpe que quiser (A, B, L, R). Golpes corpo a corpo avançam sozinhos até o saco.
- Depois de cada golpe os 3 jurados dão uma nota de 1 a 10 (golpe forte e que acertou o saco vale mais; repetir o mesmo golpe vale menos). As notas somam nos pontos do concurso e a colocação final alimenta a tela de resultados e as fitas do próprio jogo.
- Body Slam agora é uma meia esfera (cúpula) cinza caindo de cima no alvo (também no FireRed e nas batalhas normais).
- Concursos por cabo/sem fio continuam com a tela original do jogo. O saco é o slot 511 do pacote de sprites.
- Testado só no mGBA (cena, turnos, notas, colocação e volta ao Salão de Concursos pelo script real do jogo). Não testado: My Boy! nem as categorias/ranks em sequência.

## Correção: Rollout reiniciava o jogo
- O multiplicador de dano do Rollout era uma variável global gravável, mas o código roda direto da ROM, e gravar ali pode reiniciar o jogo. Agora o valor fica na memória da própria batalha, e o build recusa qualquer variável global gravável.

## Atualização: Rock Smash e Leaf Blade
- Rock Smash: um punho preto que se crava numa rocha, que treme e se despedaça.
- Leaf Blade: uma lâmina verde em forma de folha cortando o alvo.

## Atualização: experiência no fim da batalha
- A experiência de todos os adversários derrotados agora é paga só quando a batalha termina (depois do último Pokémon do treinador, ou da dupla de treinadores). Aí aparecem os ganhos, os level-ups, golpes novos e evoluções, e só depois o prêmio em dinheiro. Em batalhas selvagens, logo após o Pokémon desmaiar.

## Atualização: Twister
- Twister agora é um projétil: um turbilhão de vento deitado, em forma de funil comprido (um único funil de 64 pixels, ponta à frente, girando) que viaja até o alvo.

## Atualização: Trainer Hill em tempo real
- As batalhas da Trainer Hill (individuais e duplas) agora rodam na arena, como o Battle Frontier. O jogo monta o time do adversário, a arena mostra a classe e o nome dele, e o resultado volta para os scripts da Hill (cronômetro, andares, vitória/derrota). Não há EXP nem dinheiro por batalha, como no jogo original.
- O modo fácil (menu L) também vale na Hill: adversários com 1/4 da vida.
- Testado só no mGBA (início da batalha com o nome do treinador e o caminho de derrota). A vitória usa o mesmo código das outras batalhas e não foi testada na Hill.

## Atualização: Twister, Psywave, Horn Drill, Hydro Pump, Facade e sono
Mesmas mudanças do FireRed: Twister com a parte grossa virada para o inimigo; Psywave em 3 ondas (sprite do Surf, cor Psychic); Horn Drill como broca girando; Hydro Pump com jato curto; Facade como hélice azul; sono/congelamento sempre expira (limite ~10 s).

## Atualização: Hydro Pump e Milotic seguidor
Mesmas correções do FireRed (bolha do Hydro Pump mais fina; Milotic seguidor apoiado no chão).

## Atualização: Heat Wave e Dragon Dance
Mesmas mudanças do FireRed (ventania de fogo de longa distância; anéis de energia roxa girando).

## Ajuste: Dragon Dance
Um único círculo horizontal de energia roxa girando (igual ao FireRed).

## Ajuste: Dragon Dance (anel maior)
Anel largo que envolve o corpo todo (igual ao FireRed).

## Atualização: Ice Ball
Bola de gelo com rastro de ar gelado, golpe à distância (igual ao FireRed).

## Ajuste: Ice Ball
Apenas um rastro de ar gelado.

## Ajuste: Ice Ball (tamanho)
Bola e rastro em 3/5 do tamanho.

## Atualização: Reflect, Light Screen e Barrier
Espelho quadrado transparente em volta do Pokémon, bloqueia todo dano por 5 s (igual ao FireRed).

## Atualização: Substitute
O Pokémon vira uma Clefairy de brinquedo por 5 s, sem dano, e depois volta ao normal (igual ao FireRed).

## Atualização: Mirror Move, Acid, limite dos espelhos e Kecleon
Mesmas mudanças do FireRed. Além disso: os Kecleon invisíveis da Rota 120 (e outros encontros de roteiro) agora são batalhas contra a espécie certa, em vez de serem sorteados.

## Correção: reinício aleatório na Rota 120
A versão principal do Emerald era compilada com -Os e reiniciava o jogo de forma aleatória ao entrar em batalhas selvagens na Rota 120; a versão _alt (-O1) não tinha o problema. Agora as duas usam a compilação -O1 (build.sh do Emerald já usa -O1 por padrão).

## Atualização: sprites para os golpes de status
Os mesmos 34 golpes de status ganharam sprites e animações originais (tools/statusfx.py), iguais aos do FireRed.

## Atualização: Grovyle mais verde no overworld
O seguidor Grovyle no mapa usa agora a mesma rampa de verdes brilhantes da arena (tools/tweak_sprites.py aplicado também ao follow.bin).

## Atualização: Dig, Secret Power e protagonista no Safari
- Dig e Secret Power passam a funcionar nos scripts do mapa sem que nenhum Pokémon da equipe conheça o golpe (mesmo mecanismo do Cut, Surf, Flash etc.): abrem a câmara dos Regis e permitem criar bases secretas. Como os outros golpes de campo, a animação mostra o primeiro Pokémon da equipe.
- Safari Zone: o protagonista na arena agora usa o sprite do Brendan ou da May do Emerald (antes era o Red/Leaf do FireRed).

## Atualização: Hidden Power
O Hidden Power agora é um golpe de longa distância aleatório: a cada uso sorteia um entre 20 ataques à distância (Ember, Water Gun, Thunder Shock, Ice Beam, Flamethrower, Thunderbolt, Psybeam, Gust, Confusion, Shadow Ball, Signal Beam, Water Pulse, Sludge Bomb, Rock Throw, Mud Shot, Silver Wind, Razor Leaf, Bubble, Acid, Vine Whip) e usa a animação, o tipo e o dano do golpe sorteado.

## Atualização: seguidores alinhados
- Os seguidores mantêm o tamanho original; ficam sempre em linha reta atrás do personagem, a 1,6 tiles (26 px), para todas as espécies (os grandes não têm mais distância extra).

- Distância ajustada: agora há um vão de cerca de 1,6 tiles entre o corpo do personagem e o do seguidor (antes os sprites quase se tocavam); seguidores grandes ficam um pouco mais atrás para manter o mesmo vão.

- Distância final dos seguidores: 24 px (1,5 tile) atrás do personagem, igual na frente, nas costas e nos lados, para todas as espécies (grandes e pequenas).

- Seguidor visto de costas (personagem andando para cima): um pouco mais de espaço (31 px); nas demais direções continua a 24 px.

## Atualização: grama alta e algas (Emerald)
- Na grama alta (long grass, Rotas 119/120 etc.) os Pokémon seguidores e os selvagens visíveis agora aparecem por cima da grama, mesmo com o jogador dentro dela; antes sumiam.
- Debaixo d'água (mergulho), os Pokémon selvagens agora aparecem nas algas e há encontros com eles ao encostar.

- Correção do "pulo": o seguidor agora acompanha a posição suave do personagem durante a caminhada (antes ele avançava 16 px de uma vez no início de cada passo e entrava no sprite do personagem).

## Atualização: Swift
- Swift agora é um golpe de longa distância: dispara estrelas contra o alvo (antes era uma explosão ao redor do usuário).

- Distância dos seguidores por tamanho do corpo: de lado e de costas o corpo do seguidor sobrepõe o personagem nos mesmos 8 px que o seguidor de frente (o espaço do Milotic de frente), para todas as espécies. O tamanho do corpo (largura e altura) agora vai no follow.bin.

## Atualização: novos efeitos de golpes e clima (Sandstorm / Hail)
- **Peck**: mesmo sprite do Megahorn. **Tackle**: o sprite do Pursuit (ameba), mas branco, voando até o alvo. **Quick Attack**: corte azul em forma de "U" deitado, com a abertura virada para o seu Pokémon, voando até o alvo.
- **Powder Snow**: vento com partículas de neve. **Silver Wind**: vento com partículas brancas.
- **Rock Slide**: várias rochas caindo sobre o alvo. **Flame Wheel**: o Pokémon vira uma roda de fogo e rola até o inimigo (um acerto; depois volta ao normal).
- **Mud Shot**: fileira de bolas de barro disparadas como o Flamethrower (longa distância). **Mud Sport**: o sprite original, em marrom, várias bolinhas (longa distância). **Mud-Slap**: funil de barro deitado, parte grossa contra o inimigo (longa distância).
- **Magical Leaf**: várias folhas verdes em forma de bumerangue, deitadas (longa distância). **Whirlpool**: funil de água como o Mud-Slap (longa distância). **Heat Wave**: funil de fogo como o Twister. **Spider Web**: rede de teia (longa distância).
- **Wrap**: um emaranhado de raízes prende o inimigo enquanto ele estiver preso (o dano de 1/16 do prender continua como antes). **Sunny Day**: o mesmo sprite, brilhando como o sol sobre o Pokémon por alguns segundos (só visual; não muda o dano de Fogo/Água).
- **Sandstorm / Hail**: o clima dura até o fim da batalha (grãos de areia / granizo caindo na tela). Em tempo real, a cada ~3 segundos todos perdem 1/16 do HP máximo, exceto Rock, Ground e Steel na areia e Ice no granizo. Usar o mesmo clima de novo falha.
- Observação: Tackle e Quick Attack agora são projéteis (como Pursuit), não golpes de contato.
- Testado só no emulador mGBA (não em My Boy!, hardware real ou cabo link).

## Duas versões do patch
`Emerald_Arena.bps` (código compilado com -O1) e `Emerald_Arena_alt.bps` (o mesmo código compilado com -Os). Use a principal; a `_alt` só se a principal travar. Para o FireRed: `FireRed_Arena.bps` (-Os) e `FireRed_Arena_alt.bps` (-O1).

## Ajustes da última rodada
Tackle / Quick Attack voltam a ser de contato; Magical Leaf com quatro folhas pequenas; Mud Sport disparado para a frente; Signal Beam com raio multicolorido; Fire/Ice/Thunder Punch com punho elemental; seguidores com 8 px extras de espaço ao andar de lado.

## Piso de quadra
Piso de areia com linhas e círculo central em: ginásios (battleType 1), salas da Elite Four (5 a 8), Pokémon League/Ever Grande (seção 15), Battle Frontier e Trainer Hill (toda batalha em que o jogo monta o time) e batalhas multiplayer (link). **Testado:** só o piso forçado por debug no emulador. **Não testado:** detecção em ginásio/Elite Four/Frontier reais no Emerald.

## Multiplayer mais rápido e estável (protocolo de link novo)

**Problema:** na batalha por cabo o jogo ficava com movimentos e golpes em câmera lenta. A cada quadro eram feitas várias trocas de bytes (pare-e-espere) com o outro console, e o tempo de espera estourava o quadro de 1/60 s.

**Correção (`LinkKeys` em `src/arena_e.c`):** agora há uma única troca de 16 bits por quadro, em modo multi-player do SIO, com as duas pontas rodando a mesma simulação (lockstep). A palavra enviada leva: 3 bits de número do quadro (para alinhar as pontas), 3 bits de hash do estado (detecta dessincronia; 4 divergências seguidas encerram a batalha) e 10 bits de teclas. Também vale para a intro e o fade-in. Se o outro lado não responde por ~2 s (5 s nos primeiros quadros), a batalha é encerrada em vez de travar.

**Testado:** só em emuladores. Dois consoles mGBA emulados em lockstep (FireRed/Crystal Advance): 877 de 900 quadros por quadro emulado (97%), contra 422 (47%) antes. Telas e contagem de quadros idênticas nos dois lados; uma luta de 2905 quadros com teclas aleatórias ficou sincronizada; um desmaio forçado encerrou a batalha nos dois e ambos voltaram ao mapa. **Não testado:** cabo real, My Boy!, outros emuladores e o caminho de link do Emerald (compila, mas não foi rodado nos dois consoles). O hash de 3 bits detecta dessincronia com menos segurança que o anterior.

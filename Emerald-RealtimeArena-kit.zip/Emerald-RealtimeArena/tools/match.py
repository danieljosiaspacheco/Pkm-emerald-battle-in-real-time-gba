import struct, re, sys
FR=open('/home/claude/work/fr.gba','rb').read(); EM=open('/home/claude/work/em.gba','rb').read()
def norm(b):
    """mask bl pairs and pc-relative ldr operand; returns bytes with masked parts zeroed"""
    o=bytearray(b); i=0
    while i+1<len(o):
        h=o[i]|(o[i+1]<<8)
        if (h&0xF800)==0xF000 and i+3<len(o):
            h2=o[i+2]|(o[i+3]<<8)
            if (h2&0xF800)==0xF800:
                o[i]=o[i+1]=o[i+2]=o[i+3]=0; i+=4; continue
        if (h&0xF800)==0x4800: o[i]=0   # ldr rd,[pc,#imm]: keep rd, drop imm
        i+=2
    return bytes(o)
def find(fr_addr,n=48,tries=(48,40,32,64,80,24)):
    off=fr_addr&0x1FFFFFE
    for n in tries:
        pat=norm(FR[off:off+n]); res=[]
        # candidate positions: 2-aligned; check masked equality
        first=FR[off:off+2]
        for m in re.finditer(re.escape(FR[off+0:off+2]) if False else b'',b''): pass
        res=[]
        # speed: search on exact first 2 bytes then verify
        start=0
        while True:
            p=EM.find(FR[off+1:off+2],start)  # high byte of first halfword (opcode class)
            if p<0: break
            q=p-1
            if q%2==0 and q+n<=len(EM) and norm(EM[q:q+n])==pat: res.append(q)
            start=p+1
        if len(res)==1: return n,res[0]
        if len(res)>1 and n>=64: return n,res
    return 0,res
if __name__=='__main__':
    syms={}
    for l in open('/home/claude/work/hack/src/gamesyms.ld'):
        m=re.match(r'(\w+) = (0x[0-9A-Fa-f]+);',l)
        if m: syms[m.group(1)]=int(m.group(2),16)
    for k,v in syms.items():
        if 0x8000000<=v<0x9000000 and v&1:
            n,r=find(v-1)
            print(k,hex(v),n,[hex(x|0x8000001) for x in (r if isinstance(r,list) else [r])] if r else 'NONE')

#!/usr/bin/env python3
"""make_rom_em.py - Pokemon Emerald (USA/Europe) version of make_rom.py.
  python3 make_rom_em.py EMERALD.gba FIRERED.gba --sprites pack.bin [--code arena.bin] OUT.gba
FIRERED.gba is only used as a source for the move-effect sprites, Poke Ball sprites and player sprites (same data as the FireRed build)."""
import sys, os, struct, hashlib, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_rom as M

EM_MD5 = "605b89b67018abcea91e693a4dd25be3"
HOOK_OFFSET = 0xB0658            # literal pool of Task_BattleStart: CB2_InitBattle | 1
HOOK_ORIG = 0x08036761
EXTRA_HOOKS = [0x163AC0, 0xB1200]                 # Battle Frontier battle starts (not real-time yet)
STD_WILD = 0xB5288
STD_WILD_HEAD = b"\xf0\xb5"
BUILD_OAM = 0x08006A0C
BUILD_OAM_CALL = 0x85E3A         # bl BuildOamBuffer in OverworldBasic
VENEER_OFF = 0xD0
MOVES = 0x0831C898 - 0x08000000   # gBattleMoves
EVO_TABLE = 0x0832531C - 0x08000000
LEARN_TABLE = 0x0832937C - 0x08000000

def install_veneer(rom, entry):
    base = 0x08000000 + VENEER_OFF
    if bytes(rom[VENEER_OFF:VENEER_OFF + 28]) != b"\x00" * 28:
        sys.exit("veneer area is not free")
    code = struct.pack("<H", 0xB500) + M.bl(base + 2, BUILD_OAM)
    code += struct.pack("<HHHHHHH", 0x4803, 0x4903, 0x468E, 0x4700, 0xBC01, 0x4700, 0x46C0)
    code += struct.pack("<II", entry, (base + 14) | 1)
    rom[VENEER_OFF:VENEER_OFF + 28] = code
    call = 0x08000000 + BUILD_OAM_CALL
    if bytes(rom[BUILD_OAM_CALL:BUILD_OAM_CALL + 4]) != M.bl(call, BUILD_OAM):
        sys.exit("field loop call site mismatch")
    rom[BUILD_OAM_CALL:BUILD_OAM_CALL + 4] = M.bl(call, base)

def patch_pp(rom):
    for m in range(1, 355):
        o = MOVES + 12 * m + 4
        if rom[o] in (5, 10): rom[o] = 15

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("emerald"); ap.add_argument("firered"); ap.add_argument("out")
    ap.add_argument("--sprites", required=True); ap.add_argument("--follow")
    ap.add_argument("--code", default=os.path.join(HERE, "..", "build_em", "arena.bin"))
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    em = bytearray(open(a.emerald, "rb").read())
    md5 = hashlib.md5(em).hexdigest()
    if (md5 != EM_MD5 or len(em) != 0x1000000) and not a.force:
        sys.exit("This is not Pokemon Emerald (USA/Europe) v1.0 (md5 %s)" % md5)
    fr = open(a.firered, "rb").read()
    code = open(a.code, "rb").read()
    if len(code) > M.CODE_MAX: sys.exit("arena code too big")
    magic, entry, guard, follower, evogate, hmcheck, clubentry, ruinentry, brainhook, pikehook = struct.unpack_from("<IIIIIIIIII", code, 0)
    assert magic == 0x414E5241
    pack = open(a.sprites, "rb").read()
    import trainer_rec
    # Safari Zone: the player is Brendan (slot 509) / May (slot 510), taken from Emerald's own overworld sprites
    pack = trainer_rec.add_to_pack(pack, em, chars={"red": (0x8505A8C, 0x84987F8), "leaf": (0x8507144, 0x84A4278)})
    import bag_rec
    pack = bag_rec.add_to_pack(pack)           # slot 511: the Contest Hall punching bag
    rom = em + b"\xff" * (M.ROM_SIZE - len(em))
    rom[M.CODE_OFF:M.CODE_OFF + len(code)] = code
    rom[M.PACK_OFF:M.PACK_OFF + len(pack)] = pack
    if M.PACK_OFF + len(pack) > M.FX_OFF: sys.exit("sprite pack overlaps the move-effect area")
    import extract_movefx
    fx = extract_movefx.pack(a.firered)
    rom[M.FX_OFF:M.FX_OFF + len(fx)] = fx
    if M.FX_OFF + len(fx) > M.ITEM_OFF: sys.exit("move-effect pack overlaps the item table")
    # hooks
    if struct.unpack_from("<I", rom, HOOK_OFFSET)[0] != HOOK_ORIG: sys.exit("hook point mismatch")
    struct.pack_into("<I", rom, HOOK_OFFSET, entry | 1)
    for off in EXTRA_HOOKS:
        if struct.unpack_from("<I", rom, off)[0] != HOOK_ORIG: sys.exit("hook mismatch %x" % off)
        struct.pack_into("<I", rom, off, entry | 1)
    if a.follow and follower:
        follow = open(a.follow, "rb").read()
        if M.FOLLOW_OFF + len(follow) > M.ROM_SIZE: sys.exit("follower pack too large")
        rom[M.FOLLOW_OFF:M.FOLLOW_OFF + len(follow)] = follow
        # visible wild Pokemon replace the random grass / cave / surf encounters: StandardWildEncounter() never triggers
        if bytes(rom[STD_WILD:STD_WILD + 2]) != STD_WILD_HEAD: sys.exit("StandardWildEncounter mismatch")
        rom[STD_WILD:STD_WILD + 4] = b"\x00\x20\x70\x47"
    if follower: install_veneer(rom, follower | 1)
    if evogate:
        # Rare Candy / level-ups in the party menu ask "DO YOU WANT TO EVOLVE?" (PartyMenuTryEvolution -> BeginEvolutionScene)
        EV, CALL, BEGIN = 0xEC, 0x1B7848, 0x0813DA40
        if bytes(rom[EV:EV + 16]) != b"\x00" * 16: sys.exit("evolution veneer area is not free")
        rom[EV:EV + 16] = struct.pack("<HHHHHHI", 0xB410, 0x4C02, 0x46A4, 0xBC10, 0x4760, 0x46C0, (evogate | 1))
        if bytes(rom[CALL:CALL + 4]) != M.bl(0x08000000 + CALL, BEGIN): sys.exit("BeginEvolutionScene call site mismatch")
        rom[CALL:CALL + 4] = M.bl(0x08000000 + CALL, 0x08000000 + EV)
    if clubentry:
        # Cable Club (Pokemon Center 2F): the Colosseum counter opens the real-time link screen instead of the game's own link
        # Contest Hall: CB2_SetStartContestCallback (SetMainCallback2(CB2_StartContest)) jumps to the arena version of the appeals
        CSC = 0xF83D0
        if ruinentry:
            assert bytes(rom[CSC:CSC + 4]) != b"\x00\x48\x00\x47", "contest hook already applied"
            rom[CSC:CSC + 8] = b"\x00\x48\x00\x47" + struct.pack("<I", ruinentry | 1)      # ldr r0,[pc] ; bx r0 ; .word ContestEntry
        CLUB = 0x276EB7                                  # CableClub_EventScript_Colosseum: copyvar 0x8007, VAR_LAST_TALKED ; goto SelectBattleMode
        if rom[CLUB] != 0x19: sys.exit("Cable Club Colosseum script mismatch")
        rom[CLUB:CLUB + 6] = b"\x23" + struct.pack("<I", clubentry | 1) + b"\x02"          # callnative ClubEntry ; end
    if hmcheck:
        # field moves without a Pokemon that knows them: script command 0x7C -> HmCheck, PartyHasMonWithSurf -> true
        slot = 0x1DB67C + 4 * 0x7C
        if struct.unpack_from("<I", rom, slot)[0] != 0x0809B3DD: sys.exit("checkpartymove table entry mismatch")
        struct.pack_into("<I", rom, slot, hmcheck | 1)
        if bytes(rom[0x8BE00:0x8BE02]) != b"\x30\xb5": sys.exit("PartyHasMonWithSurf mismatch")
        rom[0x8BE00:0x8BE04] = b"\x01\x20\x70\x47"
    for fn, hk in ((0x1A3610, brainhook), (0x1A8590, pikehook)):
        # Battle Frontier leaders in the 7th battle: GetFrontierBrainStatus / GetPikeQueenFightType jump to the hack
        if bytes(rom[fn:fn + 2])[1] != 0xB5 and bytes(rom[fn:fn + 2])[1] != 0xB4: sys.exit("brain hook: unexpected function start at %x" % fn)
        rom[fn:fn + 8] = b"\x00\x4b\x18\x47" + struct.pack("<I", hk | 1)       # ldr r3,[pc] ; bx r3 ; .word hook
    patch_pp(rom)
    # evolutions / learnsets / item tables / ball sprites: reuse make_rom's routine with Emerald's tables
    M.EVO_TABLE = EVO_TABLE; M.LEARN_TABLE = LEARN_TABLE
    import pack_balls
    _orig = pack_balls.pack
    pack_balls.pack = lambda b: _orig(fr[:0x1000000])      # Poke Ball sprites come from FireRed's graphics
    M.patch_evolutions(rom)
    open(a.out, "wb").write(rom)
    print("wrote %s (code %d bytes, sprite pack %.2f MB)" % (a.out, len(code), len(pack) / 1e6))

if __name__ == "__main__":
    main()

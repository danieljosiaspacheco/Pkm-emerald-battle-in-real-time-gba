#!/usr/bin/env python3
"""bag_rec.py - arena sprite record (slot 511) of the red punching bag used by the Contest Hall.
32x64 frame; frames: 0 hanging still, 1 / 2 swinging to the right / left."""
import struct
from pack_sprites import lz77


def rgb555(t):
    r, g, b = t
    return (r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10)


def frame(shear):
    W, H = 32, 64
    p = [[0] * W for _ in range(H)]
    def sx(y): return int(round(shear * max(0, y - 8) / 50.0))
    # chain from a ceiling hook
    for y in range(0, 12):
        x = 16 + (sx(y) if y > 8 else 0)
        for dx in (-1, 0, 1): p[y][x + dx] = 7 if dx else 6
        if y % 3 == 0:
            p[y][x - 1] = 6; p[y][x + 1] = 6
    # body: rounded cylinder, y 10..57
    for y in range(10, 58):
        if y < 14: hw = 5 + (y - 10) * 2
        elif y > 53: hw = 9 - (y - 53) * 2
        else: hw = 9
        c = 16 + sx(y)
        for x in range(c - hw, c + hw + 1):
            if not (0 <= x < W): continue
            v = 2
            if x <= c - hw + 3: v = 3
            if x >= c + hw - 3: v = 5
            if hw == 9 and x <= c - hw + 1: v = 4 if 16 <= y <= 50 and x == c - hw + 1 else 3
            p[y][x] = v
        # outline
        for x in (c - hw - 1, c + hw + 1):
            if 0 <= x < W: p[y][x] = 1
    for y in (9, 58):
        c = 16 + sx(y)
        for x in range(c - 4, c + 5):
            if 0 <= x < W: p[y][x] = 1
    # white tape bands + straps
    for y0 in (24, 44):
        for y in range(y0, y0 + 3):
            c = 16 + sx(y)
            for x in range(c - 9, c + 10):
                if 0 <= x < W: p[y][x] = 4 if x < c + 7 else 5
            for x in (c - 10, c + 10):
                if 0 <= x < W: p[y][x] = 1
    return p


def tiles_of(p):
    out = bytearray()
    for t in range(32):
        tx, ty = t % 4, t // 4
        for y in range(8):
            for x in range(0, 8, 2):
                a = p[ty * 8 + y][tx * 8 + x]; b = p[ty * 8 + y][tx * 8 + x + 1]
                out.append(a | (b << 4))
    return bytes(out)


def build():
    pal = [0, rgb555((70, 8, 12)), rgb555((214, 28, 36)), rgb555((255, 120, 120)), rgb555((250, 250, 250)),
           rgb555((140, 12, 24)), rgb555((160, 162, 176)), rgb555((40, 40, 48))] + [0] * 8
    fr = [tiles_of(frame(s)) for s in (0, 5, -5)]
    head = struct.pack("<BBBBBBBB", 2, 3, 3, 32, 16, 58, 0, 0) + struct.pack("<16H", *pal)
    ftab = len(head); head += b"\0" * 12
    atab = len(head); head += b"\0" * 80
    adata = bytearray(); offs = []
    def anim(es):
        o = len(head) + len(adata); adata.append(len(es))
        for e in es: adata.extend(struct.pack("<BBbbB", *e))
        return o
    still = anim([(0, 30, 0, 0, 0)])
    hurt = anim([(1, 5, 0, 0, 0), (2, 6, 0, 0, 0), (1, 6, 0, 0, 0), (2, 6, 0, 0, 0), (0, 6, 0, 0, 0)])
    for s in (still, still, still, hurt, still):
        offs += [s] * 8
    while len(adata) % 4: adata.append(0)
    rec = bytearray(head) + adata
    fo = []
    for f in fr:
        fo.append(len(rec)); rec += lz77(f)
    rec[ftab:ftab + 12] = struct.pack("<3I", *fo)
    rec[atab:atab + 80] = struct.pack("<40H", *offs)
    return bytes(rec)


def add_to_pack(pack, slot=511):
    pack = bytearray(pack)
    while len(pack) % 4: pack.append(0)
    struct.pack_into("<I", pack, 4 * slot, len(pack))
    pack += build()
    return bytes(pack)

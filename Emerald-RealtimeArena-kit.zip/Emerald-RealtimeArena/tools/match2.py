import re, sys
sys.path.insert(0,'tools')
from match import FR, EM, norm
def cands(fr_off, n, skip=0):
    pat=norm(FR[fr_off+skip:fr_off+skip+n]); res=[]; start=0
    h=FR[fr_off+skip+1:fr_off+skip+2]
    while True:
        p=EM.find(h,start)
        if p<0: break
        q=p-1
        if q%2==0 and q+n<=len(EM) and norm(EM[q:q+n])==pat: res.append(q-skip)
        start=p+1
    return res
def find2(fr_addr):
    off=fr_addr&0x1FFFFFE
    best=None
    for skip in (0,6,12,20,30,42,56):
        for n in (32,24,16):
            r=cands(off,n,skip)
            if len(r)==1: return r[0], skip, n
            if 1<len(r)<best[0] if best else 0: pass
    return None
if __name__=='__main__':
    for a in sys.argv[1:]:
        v=int(a,16); r=find2(v-1)
        print(a, hex(r[0]|0x8000001) if r else None, r)
